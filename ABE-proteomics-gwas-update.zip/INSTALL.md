# Add the proteomics and GWAS cases

Merge the contents of ai-bioinformatics-evaluation/ into your existing repository; this ZIP is an update package, not a complete replacement repository.

New chapters: 07-proteomics-case.qmd (ABE-007) and 08-gwas-case.qmd (ABE-008). Independent Evaluation is now 09-independent-evaluation.qmd (ABE-009); Next Steps is 10-next-steps.qmd (ABE-010). Appendix and References remain 99-prefixed, with IDs ABE-011 and ABE-012.

The YAML uses your latest uploaded configuration. Other existing chapters are updated from the last copies available in this conversation. Compare them with your local files before replacing any additional edits. The package updates the preface, single-cell next link, independent assignment, next steps, appendix, and References page.

The two new references are in library/abe-additional-references.bib, already added to the YAML bibliography list. Keep both existing .bib files.

If you still have the old 07-independent-evaluation.qmd and 08-next-steps.qmd, remove them from the active project after confirming the renamed versions contain your edits. Move any independent assignment work from results/ch07/ into results/ch09/ BEFORE running the new proteomics script, which uses results/ch07/. Move results/08-development-plan.md to results/10-development-plan.md if present. Do not discard learner work.

Run from the repository root:

```bash
Rscript scripts/R/07-verify-proteomics.R
Rscript scripts/R/08-verify-gwas.R
quarto render
```

Compare the generated tables with cases/proteomics/reference/ and cases/gwas/reference/. Reference values were calculated in Python; R and Quarto were unavailable in the authoring environment. No generated docs/ or R results are bundled. Numeric values, chapter links, IDs, and YAML were checked before packaging.

After rendering, check the new chapters and citations. Git may retain obsolete docs/07-independent-evaluation.html and docs/08-next-steps.html; remove only those obsolete pages after confirming the renamed pages exist. Review git status before committing.
