# Add case visualizations

Apply the proteomics/GWAS package first. This update contains five revised case chapters, five ready-to-display PNGs, and complete plotting code in R and Python. The existing directory structure is preserved. No YAML change is required.

Merge ai-bioinformatics-evaluation/ into the repository. Full chapter copies use the latest versions prepared in this conversation. If you made additional edits, use the matching chapter-inserts/ snippet near the end of each chapter instead of replacing that chapter.

From the repository root:

```bash
quarto render
```

The bundled PNGs display without installing Python or running scripts. To recreate all figures using base R:

```bash
Rscript scripts/R/plot-evaluation-cases.R
quarto render
```

An optional Python equivalent is included for provenance: scripts/python/plot-evaluation-cases.py (requires numpy and matplotlib). It was executed to generate the bundled PNGs; all five were visually inspected. The R version and Quarto rendering could not be executed in the authoring environment. Both versions compute plotted values from the supplied input tables rather than hard-coding results. Re-running either replaces the same five PNGs.

The plotting script does not replace or change the verification scripts. It performs descriptive checks and visualization, not inferential testing. Figures are placed after the review exercises so learners can save an initial judgment first.
